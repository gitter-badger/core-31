### For Feature Requests

Desired Feature:

### For Bug Reports

* BookStack Version:
* PHP Version:
* MySQL Version:

##### Expected Behavior

##### Actual Behavior
