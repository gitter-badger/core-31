<?php namespace BookStack\Exceptions;


class SocialSignInException extends NotifyException {}